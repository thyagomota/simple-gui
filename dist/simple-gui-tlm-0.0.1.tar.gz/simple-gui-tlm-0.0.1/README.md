A small example to illustrate how to package an app in python. 
This package was created using the following tutorials:
* https://packaging.python.org/tutorials/packaging-projects/
* https://pypi.org/project/PySimpleGUI/